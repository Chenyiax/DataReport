from setuptools import setup, find_packages

setup(
    name='django',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
        'Django>=4.2',
        # 其他依赖包
    ],
    entry_points={
        'console_scripts': [
            'your_cli_command=your_package_name.cli:main',
        ],
    },
)